package com.gestionfinanciera;

import java.time.LocalDate;

public class MovimientoEgreso extends Movimiento {

    private double impuesto;

    public MovimientoEgreso(int id, String descripcion, double monto, LocalDate fecha, double impuesto) {
        super(id, descripcion, monto, fecha);
        this.impuesto = impuesto;
    }

    public double getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(double impuesto) {
        this.impuesto = impuesto;
    }

    @Override
    public double calcularMontoFinal() {
        return getMonto() + impuesto;
    }

    @Override
    public String mostrarInfo() {
        return  "=== Movimiento de Egreso ===\n" +
                super.mostrarInfo() + "\n" +
                "Impuesto aplicado: " + impuesto;
    }
}
