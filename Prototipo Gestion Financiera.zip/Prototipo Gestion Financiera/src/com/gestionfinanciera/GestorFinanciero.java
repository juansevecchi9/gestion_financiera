package com.gestionfinanciera;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class GestorFinanciero {

    private ArrayList<Movimiento> movimientos;

    public GestorFinanciero() {
        this.movimientos = new ArrayList<>();
    }

    public void agregarMovimiento(Movimiento movimiento) {
        movimientos.add(movimiento);
        System.out.println("✔ Movimiento agregado correctamente.");
    }

    public void listarMovimientos() {
        if (movimientos.isEmpty()) {
            System.out.println("No hay movimientos registrados.");
            return;
        }

        System.out.println("\n=== LISTA DE MOVIMIENTOS ===");
        for (Movimiento m : movimientos) {
            m.mostrarInfo();
        }
    }

    public void mostrarResumen() {
        if (movimientos.isEmpty()) {
            System.out.println("No hay movimientos para mostrar un resumen.");
            return;
        }

        double total = 0;

        for (Movimiento m : movimientos) {
            total += m.calcularMontoFinal();
        }

        System.out.println("\n=== RESUMEN FINANCIERO ===");
        System.out.println("Saldo total: " + total);
    }

    // -------------------------------------------------------------
    // 🟦 MÉTODO EXIGIDO POR EL TP4 — ARREGLO (obligatorio)
    // -------------------------------------------------------------
    public Movimiento[] obtenerMovimientosComoArray() {
        return movimientos.toArray(new Movimiento[0]);
    }

    // -------------------------------------------------------------
    // 🟦 MÉTODO OPCIONAL — ORDENAMIENTO DEL ARREGLO (suma puntos)
    // -------------------------------------------------------------
    public Movimiento[] obtenerMovimientosOrdenadosPorFecha() {
        Movimiento[] arr = obtenerMovimientosComoArray();
        Arrays.sort(arr, Comparator.comparing(Movimiento::getFecha));
        return arr;
    }

    // -------------------------------------------------------------
    // Método para cargar datos de ejemplo (si lo usabas)
    // -------------------------------------------------------------
    public void inicializarDatosDemo() {
        // opcional — si ya lo usabas, podés dejarlo así.
    }
}
