package com.gestionfinanciera;

import java.time.LocalDate;

public abstract class Movimiento {

    // ===== ATRIBUTOS =====
    private int id;
    private String descripcion;
    private double monto;
    private LocalDate fecha;

    // 👉 AGREGADO AHORA (lo necesitaba el DAO)
    private String moneda;


    // ===== CONSTRUCTOR =====
    public Movimiento(int id, String descripcion, double monto, LocalDate fecha) {
        this.id = id;
        this.descripcion = descripcion;
        this.monto = monto;
        this.fecha = fecha;
    }


    // ===== GETTERS Y SETTERS =====

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }


    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }


    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }


    // ===== GETTER & SETTER agregados para la BD =====

    public String getMoneda() {
        return moneda;
    }

    public void setMoneda(String moneda) {
        this.moneda = moneda;
    }


    // ===== MÉTODO ABSTRACTO (polimorfismo real) =====
    public abstract double calcularMontoFinal();


    // ===== MOSTRAR INFO =====
    public String mostrarInfo() {
        return "ID: " + id +
               " | Descripción: " + descripcion +
               " | Monto: " + monto +
               " | Fecha: " + fecha +
               " | Moneda: " + moneda;
    }
}
