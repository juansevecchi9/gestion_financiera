package com.gestionfinanciera;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
import java.sql.Connection;


public class MenuPrincipal {

    public static void main(String[] args) throws Exception {

        ConexionBD.getConexion();
         // 🔥 TEST de conexión real (TEMPORAL)
        try (Connection conn = ConexionBD.getConexion()) {
        System.out.println("🎯 Conectado a la BD: " + conn.getCatalog());
        } catch (Exception e) {
        e.printStackTrace();
        }

        System.setProperty("file.encoding", "UTF-8");
        Locale.setDefault(new Locale("es", "ES"));
        Scanner sc = new Scanner(System.in, "UTF-8");

        GestorFinanciero gestor = new GestorFinanciero();
        boolean salir = false;

        gestor.inicializarDatosDemo();

        while (!salir) {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Registrar Ingreso");
            System.out.println("2. Registrar Egreso");
            System.out.println("3. Listar Movimientos");
            System.out.println("4. Mostrar Resumen Financiero");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            try {
                int opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1 -> registrarMovimiento(sc, gestor, true);
                    case 2 -> registrarMovimiento(sc, gestor, false);
                    case 3 -> gestor.listarMovimientos();
                    case 4 -> gestor.mostrarResumen();
                    case 0 -> {
                        salir = true;
                        System.out.println("👋 Saliendo del sistema. ¡Hasta luego!");
                    }
                    default -> System.out.println("⚠️ Opción no válida.");
                }

            } catch (InputMismatchException e) {
                System.out.println("❌ Error: debe ingresar un número válido.");
                sc.nextLine();
            } catch (Exception e) {
                System.out.println("❌ Error inesperado: " + e.getMessage());
            }
        }

        sc.close();
    }

    private static void registrarMovimiento(Scanner sc, GestorFinanciero gestor, boolean esIngreso) {

        System.out.print("Descripcion: ");
        String desc = sc.nextLine();

        System.out.print("Monto: ");
        double monto = sc.nextDouble();
        sc.nextLine();

        System.out.print("Moneda (ARS / USD / EUR): ");
        String moneda = sc.nextLine().toUpperCase();

        double ajusteCambio = 1.0;
        if (moneda.equals("USD")) ajusteCambio = 1000;
        if (moneda.equals("EUR")) ajusteCambio = 1100;

        double montoFinal = monto * ajusteCambio;

        if (esIngreso) {
            System.out.print("Bonificación: ");
            double bonificacion = sc.nextDouble();

            MovimientoIngreso mi = new MovimientoIngreso(
                    (int) (Math.random() * 1000),
                    desc,
                    montoFinal,
                    LocalDate.now(),
                    bonificacion
            );

            gestor.agregarMovimiento(mi);

        } else {
            System.out.print("Impuesto: ");
            double impuesto = sc.nextDouble();

            MovimientoEgreso me = new MovimientoEgreso(
                    (int) (Math.random() * 1000),
                    desc,
                    montoFinal,
                    LocalDate.now(),
                    impuesto
            );

            gestor.agregarMovimiento(me);
        }

        System.out.println("✅ Movimiento registrado en " + moneda + " (convertido automáticamente).");
    }
}
