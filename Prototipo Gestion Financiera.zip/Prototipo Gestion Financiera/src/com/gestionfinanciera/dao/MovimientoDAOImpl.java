package com.gestionfinanciera.dao;

import com.gestionfinanciera.ConexionBD;
import com.gestionfinanciera.Movimiento;
import com.gestionfinanciera.MovimientoIngreso;
import com.gestionfinanciera.MovimientoEgreso;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MovimientoDAOImpl implements MovimientoDAO {

    // ======================================================
    // INSERT
    // ======================================================
    @Override
    public void guardar(Movimiento movimiento) throws Exception {

        String sql = "INSERT INTO movimiento (tipo, fecha, monto, cod_moneda, observaciones) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String tipoDB = (movimiento instanceof MovimientoIngreso)
                    ? "ingreso"
                    : "egreso";

            ps.setString(1, tipoDB);
            ps.setDate(2, Date.valueOf(movimiento.getFecha()));
            ps.setDouble(3, movimiento.getMonto());
            ps.setString(4, movimiento.getMoneda());
            ps.setString(5, movimiento.getDescripcion());

            ps.executeUpdate();
        }
    }


    // ======================================================
    // SELECT  (Listar desde la BD)
    // ======================================================
    @Override
    public List<Movimiento> listar() throws Exception {

        List<Movimiento> lista = new ArrayList<>();

        String sql = "SELECT id_movimiento, tipo, fecha, monto, cod_moneda, observaciones "
                   + "FROM movimiento";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                int id = rs.getInt("id_movimiento");
                String tipo = rs.getString("tipo");
                LocalDate fecha = rs.getDate("fecha").toLocalDate();
                double monto = rs.getDouble("monto");
                String moneda = rs.getString("cod_moneda");
                String obs = rs.getString("observaciones");

                Movimiento mov;

                if ("ingreso".equalsIgnoreCase(tipo)) {
                    mov = new MovimientoIngreso(id, obs, monto, fecha, 0);
                } else {
                    mov = new MovimientoEgreso(id, obs, monto, fecha, 0);
                }

                mov.setMoneda(moneda);

                lista.add(mov);
            }
        }

        return lista;
    }


    // ======================================================
    // UPDATE
    // ======================================================
    @Override
    public void actualizar(Movimiento m) throws Exception {

        String sql = "UPDATE movimiento SET observaciones = ?, monto = ? WHERE id_movimiento = ?";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, m.getDescripcion());
            ps.setDouble(2, m.getMonto());
            ps.setInt(3, m.getId());

            ps.executeUpdate();
        }
    }


    // ======================================================
    // DELETE
    // ======================================================
    @Override
    public void eliminar(int idMovimiento) throws Exception {

        String sql = "DELETE FROM movimiento WHERE id_movimiento = ?";

        try (Connection conn = ConexionBD.getConexion();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, idMovimiento);
            ps.executeUpdate();
        }
    }
}
