package com.gestionfinanciera.dao;

import com.gestionfinanciera.Movimiento;
import java.util.List;

public interface MovimientoDAO {

    // INSERT
    void guardar(Movimiento movimiento) throws Exception;

    // SELECT
    List<Movimiento> listar() throws Exception;

    // UPDATE
    void actualizar(Movimiento movimiento) throws Exception;

    // DELETE
    void eliminar(int idMovimiento) throws Exception;
}
